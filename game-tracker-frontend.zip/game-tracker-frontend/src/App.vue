<template>
  <div id="app">
    <!-- Header -->
    <header class="header">
      <div class="container">
        <h1 class="header-title">Game Tracker</h1>
        <p class="header-subtitle">Отслеживай игры и пиши рецензии</p>
      </div>
    </header>

    <!-- Navigation -->
    <nav class="main-nav">
      <div class="container">
        <div class="nav-buttons">
          <button 
            @click="currentSection = 'users'" 
            :class="['nav-btn', { active: currentSection === 'users' }]"
          >
            Игроки
          </button>
          <button 
            @click="currentSection = 'reviews'" 
            :class="['nav-btn', { active: currentSection === 'reviews' }]"
            :disabled="!selectedUserId"
          >
            Рецензии
          </button>
          <button 
            @click="currentSection = 'search'" 
            :class="['nav-btn', { active: currentSection === 'search' }]"
          >
            Поиск
          </button>
        </div>
      </div>
    </nav>

    <!-- Stats -->
    <div class="stats-bar">
      <div class="container">
        <div class="stats">
          <span class="stat">{{ totalGames }}+ игр</span>
          <span class="stat">{{ totalReviews }}+ рецензий</span>
          <span class="stat">{{ users.length }}+ пользователей</span>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <main class="main-content">
      <div class="container">
        <!-- Users Section -->
        <section v-if="currentSection === 'users'" class="section">
          <h2 class="section-title">Сообщество игроков</h2>
          <div class="users-list">
            <div 
              v-for="user in users" 
              :key="user.id" 
              class="user-item"
              @click="selectUser(user)"
              :class="{ selected: selectedUserId === user.id }"
            >
              <div class="user-avatar">{{ user.username.charAt(0).toUpperCase() }}</div>
              <div class="user-details">
                <h3 class="user-name">{{ user.username }}</h3>
                <p class="user-email">{{ user.email }}</p>
                <div class="user-meta">
                  <span>ID: {{ user.id }}</span>
                  <span>{{ formatDate(user.created_at) }}</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Reviews Section -->
        <section v-if="currentSection === 'reviews'" class="section">
          <div class="section-header">
            <h2 class="section-title">Рецензии {{ selectedUser?.username }}</h2>
            <div class="section-actions">
              <span class="review-count">{{ reviews.length }} рецензий</span>
              <button @click="loadUserReviews(selectedUserId)" class="action-btn">Обновить</button>
            </div>
          </div>

          <div v-if="loading" class="loading">
            <p>Загружаем рецензии...</p>
          </div>

          <div v-else class="reviews-list">
            <div 
              v-for="review in reviews" 
              :key="review.id" 
              class="review-item"
            >
              <div class="review-header">
                <h3 class="game-title">{{ review.game_name }}</h3>
                <span class="game-rating">{{ review.overall_rating }}/90</span>
              </div>
              
              <h4 class="review-title">{{ review.title }}</h4>
              
              <p class="review-content">
                {{ review.content }}
              </p>

              <div class="ratings">
                <div class="rating">
                  <span>Геймплей:</span>
                  <span>{{ review.gameplay_rating }}/10</span>
                </div>
                <div class="rating">
                  <span>Графика:</span>
                  <span>{{ review.graphics_rating }}/10</span>
                </div>
                <div class="rating">
                  <span>Сюжет:</span>
                  <span>{{ review.story_rating }}/10</span>
                </div>
                <div class="rating">
                  <span>Музыка:</span>
                  <span>{{ review.music_rating }}/10</span>
                </div>
                <div class="rating">
                  <span>Атмосфера:</span>
                  <span>{{ review.atmosphere_rating }}/10</span>
                </div>
              </div>

              <div class="review-footer">
                <span>Игра #{{ review.game_id }}</span>
                <span>{{ formatDate(review.created_at) }}</span>
              </div>
            </div>
          </div>

          <div v-if="!loading && reviews.length === 0" class="empty-state">
            <p>Этот игрок еще не оставил ни одной рецензии</p>
          </div>
        </section>

        <!-- Search Section -->
        <section v-if="currentSection === 'search'" class="section">
          <h2 class="section-title">Поиск рецензий по игре</h2>
          
          <div class="search-container">
            <input 
              v-model="gameId" 
              type="number" 
              placeholder="Введите ID игры..."
              @keyup.enter="searchGame"
              class="search-input"
            >
            <button @click="searchGame" class="search-btn">Найти</button>
          </div>

          <div v-if="searchResults.length > 0" class="search-results">
            <h3>Найдено рецензий: {{ searchResults.length }}</h3>
            <div class="reviews-list">
              <div 
                v-for="review in searchResults" 
                :key="review.id" 
                class="review-item"
              >
                <div class="review-header">
                  <h3 class="game-title">{{ review.game_name }}</h3>
                  <span class="game-rating">{{ review.overall_rating }}/90</span>
                </div>
                <h4 class="review-title">{{ review.title }}</h4>
                <p class="review-content">{{ review.content }}</p>
                <div class="ratings">
                  <div class="rating">
                    <span>Геймплей:</span>
                    <span>{{ review.gameplay_rating }}/10</span>
                  </div>
                  <div class="rating">
                    <span>Графика:</span>
                    <span>{{ review.graphics_rating }}/10</span>
                  </div>
                  <div class="rating">
                    <span>Сюжет:</span>
                    <span>{{ review.story_rating }}/10</span>
                  </div>
                  <div class="rating">
                    <span>Музыка:</span>
                    <span>{{ review.music_rating }}/10</span>
                  </div>
                  <div class="rating">
                    <span>Атмосфера:</span>
                    <span>{{ review.atmosphere_rating }}/10</span>
                  </div>
                </div>
                <div class="review-footer">
                  <span>Игрок #{{ review.user_id }}</span>
                  <span>{{ formatDate(review.created_at) }}</span>
                </div>
              </div>
            </div>
          </div>

          <div v-else-if="searched" class="empty-state">
            <p>Для игры с ID {{ gameId }} нет рецензий</p>
          </div>
        </section>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const API_BASE = 'http://ukprkfj-m4.wsr.ru/game-tracker/public/api'

// Data
const currentSection = ref('users')
const users = ref([])
const reviews = ref([])
const searchResults = ref([])
const selectedUserId = ref(null)
const selectedUser = ref(null)
const gameId = ref('')
const loading = ref(false)
const searched = ref(false)

// Computed
const totalGames = computed(() => {
  const allGames = [...reviews.value, ...searchResults.value]
  const uniqueGames = new Set(allGames.map(review => review.game_id))
  return uniqueGames.size
})

const totalReviews = computed(() => {
  return reviews.value.length + searchResults.value.length
})

// Methods
const loadUsers = async () => {
  try {
    const response = await fetch(`${API_BASE}/users`)
    const data = await response.json()
    users.value = data.users || []
  } catch (error) {
    console.error('Ошибка загрузки пользователей:', error)
  }
}

const selectUser = (user) => {
  selectedUserId.value = user.id
  selectedUser.value = user
  currentSection.value = 'reviews'
  loadUserReviews(user.id)
}

const loadUserReviews = async (userId) => {
  loading.value = true
  try {
    const response = await fetch(`${API_BASE}/reviews/user/${userId}`)
    const data = await response.json()
    reviews.value = data.reviews || []
  } catch (error) {
    console.error('Ошибка загрузки рецензий:', error)
    reviews.value = []
  } finally {
    loading.value = false
  }
}

const searchGame = async () => {
  if (!gameId.value) return
  
  searched.value = true
  try {
    const response = await fetch(`${API_BASE}/reviews/game/${gameId.value}`)
    const data = await response.json()
    searchResults.value = data.reviews || []
  } catch (error) {
    console.error('Ошибка поиска:', error)
    searchResults.value = []
  }
}

const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('ru-RU')
}

// Lifecycle
onMounted(() => {
  loadUsers()
})
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f5f5f5;
  color: #333;
  line-height: 1.5;
}

.container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Header */
.header {
  background: #2c3e50;
  color: white;
  padding: 2rem 0;
  text-align: center;
}

.header-title {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
}

.header-subtitle {
  color: #bdc3c7;
  font-size: 1.1rem;
}

/* Navigation */
.main-nav {
  background: #34495e;
  padding: 1rem 0;
}

.nav-buttons {
  display: flex;
  gap: 0;
  background: white;
  border-radius: 6px;
  padding: 4px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.nav-btn {
  flex: 1;
  background: none;
  border: none;
  padding: 0.75rem 1rem;
  cursor: pointer;
  border-radius: 4px;
  font-size: 0.95rem;
  transition: all 0.2s;
  color: #333;
  font-weight: 500;
}

.nav-btn:hover {
  background: #f8f9fa;
}

.nav-btn.active {
  background: #3498db;
  color: white;
}

.nav-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  background: #f8f9fa;
  color: #999;
}

/* Stats */
.stats-bar {
  background: white;
  border-bottom: 1px solid #e0e0e0;
  padding: 1rem 0;
}

.stats {
  display: flex;
  justify-content: center;
  gap: 2rem;
}

.stat {
  color: #7f8c8d;
  font-size: 0.9rem;
  font-weight: 500;
}

/* Main Content */
.main-content {
  padding: 2rem 0;
  min-height: 60vh;
}

.section {
  background: white;
  border-radius: 8px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.section-title {
  font-size: 1.5rem;
  font-weight: 600;
  margin-bottom: 1.5rem;
  color: #2c3e50;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
  gap: 1rem;
}

.section-actions {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.review-count {
  color: #7f8c8d;
  font-size: 0.9rem;
}

.action-btn {
  background: #3498db;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: background-color 0.2s;
}

.action-btn:hover {
  background: #2980b9;
}

/* Users List */
.users-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.user-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s;
}

.user-item:hover {
  border-color: #3498db;
  background: #f8f9fa;
}

.user-item.selected {
  border-color: #3498db;
  background: #ebf5fb;
}

.user-avatar {
  width: 40px;
  height: 40px;
  background: #3498db;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  color: white;
  font-size: 1.1rem;
}

.user-details {
  flex: 1;
}

.user-name {
  font-weight: 600;
  margin-bottom: 0.25rem;
  color: #2c3e50;
}

.user-email {
  color: #7f8c8d;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
}

.user-meta {
  display: flex;
  gap: 1rem;
  font-size: 0.8rem;
  color: #95a5a6;
}

/* Reviews */
.reviews-list {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.review-item {
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  padding: 1.5rem;
  transition: border-color 0.2s;
}

.review-item:hover {
  border-color: #3498db;
}

.review-header {
  display: flex;
  justify-content: space-between;
  align-items: start;
  margin-bottom: 1rem;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.game-title {
  font-size: 1.2rem;
  font-weight: 600;
  color: #2c3e50;
}

.game-rating {
  background: #27ae60;
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
}

.review-title {
  font-size: 1.1rem;
  font-weight: 500;
  margin-bottom: 1rem;
  color: #34495e;
}

.review-content {
  color: #555;
  line-height: 1.6;
  margin-bottom: 1.5rem;
}

.ratings {
  background: #f8f9fa;
  border-radius: 4px;
  padding: 1rem;
  margin-bottom: 1rem;
}

.rating {
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.5rem;
  padding: 0.25rem 0;
}

.rating:last-child {
  margin-bottom: 0;
}

.review-footer {
  display: flex;
  justify-content: space-between;
  padding-top: 1rem;
  border-top: 1px solid #e0e0e0;
  font-size: 0.8rem;
  color: #7f8c8d;
  flex-wrap: wrap;
  gap: 0.5rem;
}

/* Search */
.search-container {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 2rem;
  max-width: 400px;
}

.search-input {
  flex: 1;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  transition: border-color 0.2s;
}

.search-input:focus {
  outline: none;
  border-color: #3498db;
}

.search-btn {
  background: #27ae60;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  white-space: nowrap;
  transition: background-color 0.2s;
}

.search-btn:hover {
  background: #219a52;
}

/* States */
.loading {
  text-align: center;
  padding: 3rem;
  color: #7f8c8d;
  font-style: italic;
}

.empty-state {
  text-align: center;
  padding: 3rem;
  color: #7f8c8d;
  background: #f8f9fa;
  border-radius: 6px;
  font-style: italic;
}

/* Responsive */
@media (max-width: 768px) {
  .container {
    padding: 0 15px;
  }
  
  .header-title {
    font-size: 2rem;
  }
  
  .nav-buttons {
    flex-direction: column;
    gap: 2px;
  }
  
  .stats {
    flex-direction: column;
    gap: 0.5rem;
    text-align: center;
  }
  
  .section {
    padding: 1.5rem;
  }
  
  .section-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .search-container {
    flex-direction: column;
  }
  
  .review-header {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .review-footer {
    flex-direction: column;
  }
  
  .user-item {
    flex-direction: column;
    text-align: center;
  }
  
  .rating {
    flex-direction: column;
    gap: 0.25rem;
    text-align: center;
  }
}
</style>